<?php

interface VehiculoElectrico{
    public function cargarBateria();
    public function estadoBateria();
}