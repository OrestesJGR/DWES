<?php

    final class Bicicleta extends Vehiculo {

        public function pedalear(){

        }
        public function mover(){

        }
        
        public function detener(){
            
        }
    }