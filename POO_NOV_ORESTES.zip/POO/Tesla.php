<?php

class Tesla implements VehiculoElectrico{

    public function cargarBateria(){

    }

    public function estadoBateria(){

    }
}


?>